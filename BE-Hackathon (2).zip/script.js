/* Add a "checked" symbol when clicking on a list item*/
 var list = document.querySelector('ul');
 list.addEventListener('click', function(ev) {
   if (ev.target.tagName === 'LI') {
     console.log("its working")
     ev.target.classList.toggle('checked');
   }
 }, false);

const iframe = (address) =>`<iframe
  width="600"
  height="450"
  style="border:0"
  loading="lazy"
  allowfullscreen
  referrerpolicy="no-referrer-when-downgrade"
  src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAsrCXo3Sg8wk1ZPdLw78BVJ9cITnbqslA
    &q=${address.replace(/\s/g,"+")}">
</iframe>`
var mapCont = document.querySelector('#mapCont');
//mapCont.innerText = "hello";

var mapSel = document.querySelector("#mapSelector")
mapSel.addEventListener('change', function(ev){
  console.log(ev)
  console.log(ev.target.value)
  const map = iframe(ev.target.value)
  mapCont.innerHTML = map
})